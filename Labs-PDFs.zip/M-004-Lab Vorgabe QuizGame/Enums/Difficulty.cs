﻿namespace QuizGame.Enums
{
    public enum Difficulty
    {
        Easy = 1,
        Medium,
        Hard
    }
}
